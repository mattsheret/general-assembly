//Implement the red light using jQuery. Don't forget to add the script tags.
//console.log($);

$('#stopButton').click(function(){
	changeColour('red');
});

$('#slowButton').click(function(){
	changeColour('yellow');
});

$('#goButton').click(function(){
	changeColour('green');
});


function turnRed() {
	$('#stopLight').css('backgroundColor', 'red');
}

function changeColour(colour) {
	// Bonus - add in the 'all black' bit	
	
	console.log('new change colour function runs');
	console.log('color is ' + colour);
	$('#' + colour + 'Light').css('backgroundColor', colour);
}


