// Keep track of total amount in a variable
var total = 0.00;

// Declare func for dealing with entry
var addItem = function() {

	// Get value of latest entry
	var latestEntry = $('#newEntry').val();
	var latestEntryFormatted;
	var totalFormatted;

	// Needs to be a float
	latestEntry = parseFloat(latestEntry);

	// Call formatting function on entry
	latestEntryFormatted = format( latestEntry );

	// Add row to #entries
	$('#entries').append('<tr><td></td><td>' + latestEntryFormatted + '</td></tr>');

	// Update total value
	total = total + latestEntry;

	// Update #total in HTML (Call formatting function on total)
	totalFormatted = format(total);
	$('#total').html(totalFormatted);

	// Clear new entry val for next time
	$('#newEntry').val('');

	// Prevent form from submitting (gotcha)
	return false;
}

// Bonus function for formatting currency
var format = function(number) {
	number = parseFloat(number);
	number = number.toFixed(2);
	number = '£' + number;
	return number;
}

// Attach function to form submit event
$('#entry').submit(addItem);
